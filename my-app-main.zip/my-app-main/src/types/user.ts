interface User {
    id: number,
    username: string,
    fullname: string,
    password: string
}

export default User