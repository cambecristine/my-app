import React from "react";

const Footer: React.FC = () => {
  return (
    <div>
      <h1>Footer</h1>
    </div>
  );
};

export default Footer;
